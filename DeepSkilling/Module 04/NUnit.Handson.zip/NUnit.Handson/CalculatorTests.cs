using NUnit.Framework;
using CalcLibrary;

namespace CalcLibrary.Tests
{
    [TestFixture]
    public class CalculatorTests
    {
        private Calculator calc;

        [SetUp]
        public void SetUp()
        {
            calc = new Calculator();
        }

        [TearDown]
        public void TearDown()
        {
            calc = null;
        }

        [Test]
        [TestCase(10, 20, 30)]
        [TestCase(5, 7, 12)]
        [TestCase(2, 3, 5)]
        public void Add_Test(int a, int b, int expected)
        {
            int actual = calc.Add(a, b);
            Assert.That(actual, Is.EqualTo(expected));
        }
    }
}